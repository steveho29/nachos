#include "syscall.h"


int main()
{
   	int result = Sub(29, 10);
	Halt();
}
